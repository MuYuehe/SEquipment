local _, ns = ...

if (GetLocale() ~= "zhCN") then return end

ns.L = {
    ShowPlayerInfo                  ="显示自身面板",
    ShowTargetInfo                  ="显示目标面板",
    ShowTooltip                     ="显示鼠标提示",
    ShowWholeStat                   ="显示完整属性(不勾选仅显示装备属性包括附魔、宝石)",
    -- ShowEquipLevel                  ="显示装备等级",
    ShowClassColorFrame             ="边框显示职业色",
}